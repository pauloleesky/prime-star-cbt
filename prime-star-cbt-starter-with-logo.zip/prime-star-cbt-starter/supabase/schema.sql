-- PRIME STAR CBT initial database schema.
-- Run in Supabase SQL Editor only after creating a new Supabase project.
-- This establishes one attempt per candidate per examination.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  registration_id text unique not null,
  display_name text not null,
  role text not null default 'student' check (role in ('student','admin')),
  access_plan text not null default 'free',
  created_at timestamptz not null default now()
);

create table if not exists public.exams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text[] not null default '{}',
  instructions text,
  duration_minutes integer not null check (duration_minutes > 0),
  total_questions integer not null check (total_questions > 0),
  access_level text not null default 'free',
  status text not null default 'draft' check (status in ('draft','published','closed')),
  result_release text not null default 'immediate' check (result_release in ('immediate','scheduled','manual')),
  results_release_at timestamptz,
  calculator_enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  prompt text not null,
  options jsonb not null,
  explanation text,
  position integer not null,
  created_at timestamptz not null default now(),
  unique(exam_id, position)
);

-- Correct answers are kept separately from student-readable question data.
create table if not exists public.answer_keys (
  question_id uuid primary key references public.questions(id) on delete cascade,
  correct_option text not null check (correct_option in ('A','B','C','D'))
);

create table if not exists public.attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id),
  candidate_id uuid not null references public.profiles(id),
  started_at timestamptz not null default now(),
  submitted_at timestamptz,
  status text not null default 'in_progress' check (status in ('in_progress','submitted','expired')),
  score integer,
  total_questions integer not null,
  unique(candidate_id, exam_id)
);

create table if not exists public.responses (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id),
  selected_option text check (selected_option in ('A','B','C','D')),
  updated_at timestamptz not null default now(),
  unique(attempt_id, question_id)
);

create table if not exists public.exam_entitlements (
  id uuid primary key default gen_random_uuid(),
  access_plan text not null,
  exam_id uuid not null references public.exams(id) on delete cascade,
  unique(access_plan, exam_id)
);

alter table public.profiles enable row level security;
alter table public.exams enable row level security;
alter table public.questions enable row level security;
alter table public.answer_keys enable row level security;
alter table public.attempts enable row level security;
alter table public.responses enable row level security;
alter table public.exam_entitlements enable row level security;

-- Intentionally no public policies are added yet. Add narrowly scoped policies
-- and server-side exam/marking functions before enabling real student access.
-- Never expose the Supabase service-role key in browser code.
