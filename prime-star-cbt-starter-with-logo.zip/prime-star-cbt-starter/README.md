# PRIME STAR CBT — starter foundation

This is the first design and engineering foundation for a separate Prime Star CBT website.

## Included
- Mobile-first branded portal landing screen.
- Examination dashboard visual direction.
- Working scientific calculator preview powered by mathjs.
- Supabase database schema foundation.
- Database uniqueness rule: one candidate can have only one attempt per exam.

## Not live yet
This starter is not ready for real student examinations. Authentication, server-side exam delivery, secure answer marking, autosave/resume, admin tools, result release, entitlements and database security policies still need implementation and testing.

## Run locally
1. Install Node.js 20 or later.
2. Extract this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local` and fill in the Supabase project URL and public anon key when the Supabase project exists.
5. Run `npm run dev`.
6. Open `http://localhost:3000`.

## Important security requirements
- Never put the Supabase service-role key in frontend code.
- Do not send correct answers to the browser before submission.
- Enforce one attempt per candidate/exam in the database, not only in the interface.
- Enforce exam duration and submission on the server.
- Create role-based RLS policies and server-side marking functions before live use.

## Deployment direction
Deploy this separate Next.js project to Vercel. Connect it to its own Supabase project. The main Prime Star Tutorials website will link to this portal.


## Updated exam-screen design preview
The current starter screen includes a live preview countdown, three question font sizes,
dark/light theme toggle, a basic four-operation calculator overlay, sample answer selection,
subject tabs and question navigation. The logo is a temporary PS placeholder until the
official Prime Star logo asset is supplied. The timer and sample controls are preview-only;
real examination timing, saving and submission must be enforced by the backend.


## Official brand asset
The supplied official PRIME STAR TUTORIALS logo is included at `public/prime-star-logo.png` and displayed in the examination header. The original logo artwork is used without redesign.
