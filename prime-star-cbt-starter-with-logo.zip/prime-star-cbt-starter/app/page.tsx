"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

const options = [
  ["A", "Densities"],
  ["B", "Boiling points"],
  ["C", "Melting points"],
  ["D", "Solubilities"]
];

export default function Home() {
  const [dark, setDark] = useState(true);
  const [fontSize, setFontSize] = useState(1);
  const [seconds, setSeconds] = useState(19 * 60 + 50);
  const [calculatorOpen, setCalculatorOpen] = useState(false);
  const [display, setDisplay] = useState("0");
  const [stored, setStored] = useState<number | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [fresh, setFresh] = useState(true);
  const [chosen, setChosen] = useState<string | null>(null);

  useEffect(() => {
    const timer = window.setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const time = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;

  function calc(key: string) {
    const current = Number(display);
    if (key === "AC") { setDisplay("0"); setStored(null); setOperator(null); setFresh(true); return; }
    if (key === "⌫") { setDisplay(display.length > 1 ? display.slice(0, -1) : "0"); return; }
    if (key === ".") { if (fresh) { setDisplay("0."); setFresh(false); } else if (!display.includes(".")) setDisplay(display + "."); return; }
    if (/^\d$/.test(key)) { setDisplay(fresh || display === "0" ? key : display + key); setFresh(false); return; }
    if (key === "%") { setDisplay(String(current / 100)); setFresh(true); return; }
    if (key === "=") {
      if (stored !== null && operator) {
        const result = operator === "+" ? stored + current : operator === "−" ? stored - current : operator === "×" ? stored * current : current === 0 ? NaN : stored / current;
        setDisplay(Number.isFinite(result) ? String(Number(result.toFixed(8))) : "Error");
        setStored(null); setOperator(null); setFresh(true);
      }
      return;
    }
    setStored(current); setOperator(key); setFresh(true);
  }

  return (
    <main className={dark ? "app dark" : "app light"} style={{"--question-scale": [0.88, 1, 1.14][fontSize]} as React.CSSProperties}>
      <header className="exam-header">
        <div className="brand">
          <div className="logo-image"><Image src="/prime-star-logo.png" alt="PRIME STAR TUTORIALS official logo" fill priority sizes="44px" /></div>
          <div><strong>PRIME STAR</strong><small>TUTORIALS • CBT</small></div>
        </div>
        <div className="toolbar">
          <div className="font-tools" aria-label="Question text size">
            <button onClick={() => setFontSize(0)} aria-label="Small text">A−</button>
            <button onClick={() => setFontSize(1)} aria-label="Normal text">A</button>
            <button onClick={() => setFontSize(2)} aria-label="Large text">A+</button>
          </div>
          <button className="tool-button" onClick={() => setDark(!dark)} aria-label="Switch colour theme">{dark ? "☀" : "☾"}</button>
          <button className="tool-button calculator-launch" onClick={() => setCalculatorOpen(true)} aria-label="Open calculator">▦</button>
          <div className="timer"><span>◷</span>{time}</div>
        </div>
      </header>

      <div className="exam-wrap">
        <div className="subject-tabs">
          <button className="subject active">Chemistry <span>0/10</span></button>
          <button className="subject">Biology <span>0/10</span></button>
        </div>

        <section className="question-card">
          <div className="question-count">Question 1/10</div>
          <p className="question-text">Fractional distillation separates liquids based on differences in their</p>
          <div className="answers">
            {options.map(([letter, text]) => (
              <button key={letter} onClick={() => setChosen(letter)} className={`answer ${chosen === letter ? "selected" : ""}`}>
                <span className="letter">{letter}</span><span>{text}</span>
              </button>
            ))}
          </div>
          <div className="question-footer">
            <span>Question 1 of 10</span>
            <button className="next-button">Next question →</button>
          </div>
        </section>

        <section className="navigator">
          <div className="navigator-head"><strong>Question navigator</strong><span>0 answered • 10 remaining</span></div>
          <div className="question-numbers">{Array.from({length:10}, (_,i) => <button className={i === 0 ? "current" : ""} key={i}>{i+1}</button>)}</div>
        </section>
        <p className="preview-note">DESIGN PREVIEW — sample question and countdown only. Live examinations will use server-controlled timing and saved attempts.</p>
      </div>

      {calculatorOpen && <div className="calc-backdrop" onClick={() => setCalculatorOpen(false)}>
        <section className="calculator" onClick={(e) => e.stopPropagation()}>
          <div className="calc-heading"><strong>Calculator</strong><span>Basic</span><button onClick={() => setCalculatorOpen(false)} aria-label="Close calculator">×</button></div>
          <div className="calc-display">{display}</div>
          <div className="calc-keys">
            {["AC","⌫","%","÷","7","8","9","×","4","5","6","−","1","2","3","+","0",".","="].map((k) =>
              <button key={k} className={`${k === "AC" ? "clear" : ""} ${["÷","×","−","+","%"].includes(k) ? "operator" : ""} ${k === "=" ? "equals" : ""} ${k === "0" ? "zero" : ""}`} onClick={() => calc(k)}>{k}</button>
            )}
          </div>
        </section>
      </div>}
    </main>
  );
}
