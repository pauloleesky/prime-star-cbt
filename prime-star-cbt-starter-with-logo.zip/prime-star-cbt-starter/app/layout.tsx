import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Prime Star CBT",
  description: "PRIME STAR TUTORIALS computer-based practice and mock examinations."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
